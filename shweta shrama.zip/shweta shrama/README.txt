Simone local copy reconstructed from the supplied Chrome HAR capture.
Open index-dark.html.
Captured assets: HTML, CSS, JS, images, Font Awesome fonts, and Poppins fonts.
